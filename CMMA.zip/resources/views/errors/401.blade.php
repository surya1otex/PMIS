@extends('layouts.app')

@section('content')
<div class="content">
  <div class="animated fadeIn">
    <div class='col-lg-12'>
        <h4><center>401<br>
        You are not authorized to access this page</center></h4>
    </div>
  </div>
</div>
@endsection
