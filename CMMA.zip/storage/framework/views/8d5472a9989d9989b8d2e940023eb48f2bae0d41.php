

<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="animated fadeIn">
  <div class="row">
                        <div class="col-lg-3 col-md-6">
                            <div class="card">
                                <div class="card-body">
                                    <div class="stat-widget-five">
                                        <div class="stat-icon dib flat-color-1">
                                            <i class="pe-7s-cash"></i>
                                        </div>
                                        <div class="stat-content">
                                            <div class="text-left dib">
                                                <div class="stat-text">$<span class="count">23569</span></div>
                                                <div class="stat-heading">Revenue</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-6">
                            <div class="card">
                                <div class="card-body">
                                    <div class="stat-widget-five">
                                        <div class="stat-icon dib flat-color-2">
                                            <i class="pe-7s-cart"></i>
                                        </div>
                                        <div class="stat-content">
                                            <div class="text-left dib">
                                                <div class="stat-text"><span class="count">3435</span></div>
                                                <div class="stat-heading">Sales</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-6">
                            <div class="card">
                                <div class="card-body">
                                    <div class="stat-widget-five">
                                        <div class="stat-icon dib flat-color-3">
                                            <i class="pe-7s-browser"></i>
                                        </div>
                                        <div class="stat-content">
                                            <div class="text-left dib">
                                                <div class="stat-text"><span class="count">349</span></div>
                                                <div class="stat-heading">Templates</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-6">
                            <div class="card">
                                <div class="card-body">
                                    <div class="stat-widget-five">
                                        <div class="stat-icon dib flat-color-4">
                                            <i class="pe-7s-users"></i>
                                        </div>
                                        <div class="stat-content">
                                            <div class="text-left dib">
                                                <div class="stat-text"><span class="count">2986</span></div>
                                                <div class="stat-heading">Clients</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
    </div>
</div>
<div id="myModal" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Welcome <?php echo e(Auth::user()->fullname); ?></h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <h5><b>You logged in as <?php echo e(Auth::user()->roles->pluck('name')->first()); ?></b></h5>
                <br>
                <?php if(auth()->check() && auth()->user()->hasRole('System Admin')): ?>
				<p style="color:red">Your Permissions listed below</p>
                <ul class="roles">
                <li>You can create Users, Roles and Permissions</li>
                <li>You can assign roles and permissions to user</li>
                <li>You can create New Projects</li>
                <li>You can Upload documents</li>
                </ul>
                <?php endif; ?>
                <?php if(auth()->check() && auth()->user()->hasRole('Computer Operator')): ?>
				<p style="color:red">Your Permissions listed below</p>
                <ul class="roles">
                <li>You can create New Projects</li>
                </ul>
                <?php endif; ?>
                <?php if(auth()->check() && auth()->user()->hasRole('HOD')): ?>
				<p style="color:red">Your Permissions listed below</p>
                <ul class="roles">
                <li>You can Upload documents</li>
                </ul>
                <?php endif; ?>
                <?php if(auth()->check() && auth()->user()->hasRole('Project Approver')): ?>
				<p style="color:red">Your Permissions listed below</p>
                <ul class="roles">
                <li>You can create New Projects</li>
                <li>You can Upload documents</li>
                </ul>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<style>
.roles li {
    list-style:none;
}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\CMMA\resources\views/dashboard.blade.php ENDPATH**/ ?>